﻿# RRR Spawn Variety

- Simple system for changing and adding new mobs to world spawns. **This applies to all spawns *except* event spawns**.


- **Set up for effortless integration with my mods [RRR Monsters](https://github.com/astradamus/RRRMonsters) and/or [RRR Non-Player Characters](https://github.com/astradamus/RRRNpcs), which are already fully configured to work with this mod without additional effort.** Check the configs for those mods if you wish to modify how they appear.


- Enables both mod makers (via code) and users (via config) to specify variants for existing mob spawns in the world.
  

- A given mob can have an unlimited number of potential variants. Each variant specification includes a "weight"--the higher the weight, the greater the chance this variant is selected.
  

- Each time a mob is spawned, if any variants are defined for that mob, it will randomly select from the weighted list variants from that mob. The original variant will have a weight of 100.
  
  ### Users
    - If you do not wish to specify your own custom spawns, just install this mod and whatever other mod depends on it and you're good to go.
    - To specify your own variants in config, review the included/generated config files for variant definition examples. You will need to make sure to Enable custom config variants in the main mod config or your custom rules will not be used.
  ### Devs
    - Simply call `Registry.Add` to add a variant rule. You need to call this method every time a new game is started--returning to the main menu resets the registry. I call `Registry.Add` in a Postfix on `ZNetScene.Awake()` as this will be called once per game instance.

## Setup

Extract the zip file to your `Valheim\BepInEx` folder. Config files should end up in `Valheim\BepInEx\config`, everything else should end up in `Valheim\BepInEx\plugins`. Config files will also be generated automatically if missing.

## Help!

If you need further assistance, feel free to bug me in the Valheim Modding Discord at https://discord.gg/RBq2mzeu4z